export enum NotificationStatus {
	READ = "read",
	UNREAD = "unread",
}

export enum NotificationType {
	DEBIT = "credit",
	CREDIT = "debit",
	ACCOUNT_UPDATE = "account update",
	FAILED = "failed",
	INFO = "info",
}

export enum NotificationMessage {
	DEBIT = "credit",
	CREDIT = "debit",
	ACCOUNTUPDATE = "account update",
}
