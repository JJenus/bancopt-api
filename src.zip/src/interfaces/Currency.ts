import { symbol } from "zod";

export interface Currency {
	symbol: string;
	code: string;
}
