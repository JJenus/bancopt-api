export interface JwtToken {
	userId: string;
	name: string;
}
