export const welcomeEmail = `<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Bancopt</title>
	</head>
	<body
		style="
			background-color: #d5d9e2;
			font-family: Arial, Helvetica, sans-serif;
			line-height: 1.5;
			min-height: 100%;
			font-weight: normal;
			font-size: 15px;
			color: #2f3044;
			margin: 0;
			padding: 15px;
			width: 100%;
		"
	>
		<div
			id="#kt_app_body_content"
			style="
				background-color: #d5d9e2;
				font-family: Arial, Helvetica, sans-serif;
				line-height: 1.5;
				min-height: 100%;
				font-weight: normal;
				font-size: 15px;
				color: #2f3044;
				margin: 0;
				padding: 0;
				width: 100%;
			"
		>
			<div
				style="
					background-color: #ffffff;
					padding: 45px 0 34px 0;
					border-radius: 24px;
					margin: 40px auto;
					max-width: 600px;
				"
			>
				<table
					align="center"
					border="0"
					cellpadding="0"
					cellspacing="0"
					width="100%"
					height="auto"
					style="border-collapse: collapse"
				>
					<tbody>
						<tr>
							<td
								align="center"
								valign="center"
								style="text-align: center; padding-bottom: 10px"
							>
								<!--begin:Email content-->
								<div
									style="
										text-align: center;
										margin: 0 15px 34px 15px;
									"
								>
									<!--begin:Logo-->
									<div style="margin-bottom: 10px">
										<a
											href="https://www.bancopt.com/"
											rel="noopener"
											target="_blank"
											style="
												text-decoration: none;
												position: relative;
												display: block;
												margin-bottom: 10px;
											"
										>
											<img
												alt="Logo"
												style="
													height: 50px;
													margin-top: 10px;
												"
												src="https://www.bancopt.com/assets/media/logos/logo-ban.png"
											/>
										</a>
										<div
											align="center"
											style="
												display: block;
												color: #1b668d;
												font-weight: bolder;
												font-size: 20px;
											"
										>
											Bancopt
										</div>
									</div>
									<!--end:Logo-->

									<!--begin:Media-->
									<div style="margin-bottom: 15px">
										<img
											alt="Logo"
											src="https://www.bancopt.com/assets/media/email/icon-positive-vote-1.png"
										/>
									</div>
									<!--end:Media-->

									<!--begin:Text-->
									<div
										style="
											font-size: 14px;
											font-weight: 500;
											margin-bottom: 27px;
											font-family: Arial, Helvetica,
												sans-serif;
										"
									>
										<p
											style="
												margin-bottom: 9px;
												color: #181c32;
												font-size: 22px;
												font-weight: 700;
											"
										>
											Hey {{name}}, thanks for signing up!
										</p>
										<p
											style="
												margin-bottom: 2px;
												color: #7e8299;
											"
										>
											Your account is all set. Click
											"Verify" to verify your email.
											<br />
											Contact us on any of the available
											channels when needed.
										</p>
									</div>
									<!--end:Text-->

									<!--begin:Action-->
									<a
										href="https://www.bancopt.com/verify-email/?id={{token}}"
										target="_blank"
										style="
											background-color: #3e97ff;
											border-radius: 6px;
											display: inline-block;
											padding: 11px 19px;
											color: #ffffff;
											font-size: 14px;
											font-weight: 500;
											text-decoration: none;
										"
									>
										Verify
									</a>
									<!--begin:Action-->
								</div>
								<!--end:Email content-->
							</td>
						</tr>

						<tr
							style="
								display: flex;
								justify-content: center;
								margin: 0 60px 35px 60px;
							"
						>
							<td
								align="start"
								valign="start"
								style="padding-bottom: 10px"
							>
								<p
									style="
										color: #181c32;
										font-size: 18px;
										font-weight: 600;
										margin-bottom: 13px;
									"
								>
									What’s next?
								</p>

								<!--begin::Wrapper-->
								<div
									style="
										background: #f9f9f9;
										border-radius: 12px;
										padding: 35px 30px;
									"
								>
									<!--begin::Item-->
									<div style="display: flex">
										<!--begin::Media-->
										<div
											style="
												display: flex;
												justify-content: center;
												align-items: center;
												width: 40px;
												height: 40px;
												margin-right: 13px;
											"
										>
											<img
												alt="Logo"
												src="https://www.bancopt.com/assets/media/email/icon-polygon.png"
											/>

											<span
												style="
													position: absolute;
													color: #50cd89;
													font-size: 16px;
													font-weight: 600;
												"
											>
												1
											</span>
										</div>
										<!--end::Media-->

										<!--begin::Block-->
										<div>
											<!--begin::Content-->
											<div>
												<!--begin::Title-->
												<a
													href="#"
													style="
														color: #181c32;
														font-size: 14px;
														font-weight: 600;
														font-family: Arial,
															Helvetica,
															sans-serif;
													"
													>Complete your account</a
												>
												<!--end::Title-->

												<!--begin::Desc-->
												<p
													style="
														color: #5e6278;
														font-size: 13px;
														font-weight: 500;
														padding-top: 3px;
														margin: 0;
														font-family: Arial,
															Helvetica,
															sans-serif;
													"
												>
													Make sure your email is
													verified, upload your photo
													and gain full access to all
													our services
												</p>
												<!--end::Desc-->
											</div>
											<!--end::Content-->

											<!--begin::Separator-->
											<div
												class="separator separator-dashed"
												style="margin: 17px 0 15px 0"
											></div>
											<!--end::Separator-->
										</div>
										<!--end::Block-->
									</div>
									<!--end::Item-->
									<!--begin::Item-->
									<div style="display: flex">
										<!--begin::Media-->
										<div
											style="
												display: flex;
												justify-content: center;
												align-items: center;
												width: 40px;
												height: 40px;
												margin-right: 13px;
											"
										>
											<img
												alt="Logo"
												src="https://www.bancopt.com/assets/media/email/icon-polygon.png"
											/>

											<span
												style="
													position: absolute;
													color: #50cd89;
													font-size: 16px;
													font-weight: 600;
												"
											>
												2
											</span>
										</div>
										<!--end::Media-->

										<!--begin::Block-->
										<div>
											<!--begin::Content-->
											<div>
												<!--begin::Title-->
												<a
													href="#"
													style="
														color: #181c32;
														font-size: 14px;
														font-weight: 600;
														font-family: Arial,
															Helvetica,
															sans-serif;
													"
													>Communication Tool</a
												>
												<!--end::Title-->

												<!--begin::Desc-->
												<p
													style="
														color: #5e6278;
														font-size: 13px;
														font-weight: 500;
														padding-top: 3px;
														margin: 0;
														font-family: Arial,
															Helvetica,
															sans-serif;
													"
												>
													Make sure to contact us for
													help and guidance
												</p>
												<!--end::Desc-->
											</div>
											<!--end::Content-->

											<!--begin::Separator-->
											<div
												class="separator separator-dashed"
												style="margin: 17px 0 15px 0"
											></div>
											<!--end::Separator-->
										</div>
										<!--end::Block-->
									</div>
									<!--end::Item-->
									<!--begin::Item-->
									<div style="display: flex">
										<!--begin::Media-->
										<div
											style="
												display: flex;
												justify-content: center;
												align-items: center;
												width: 40px;
												height: 40px;
												margin-right: 13px;
											"
										>
											<img
												alt="Logo"
												src="https://www.bancopt.com/assets/media/email/icon-polygon.png"
											/>

											<span
												style="
													position: absolute;
													color: #50cd89;
													font-size: 16px;
													font-weight: 600;
												"
											>
												3
											</span>
										</div>
										<!--end::Media-->

										<!--begin::Block-->
										<div>
											<!--begin::Content-->
											<div>
												<!--begin::Title-->
												<a
													href="#"
													style="
														color: #181c32;
														font-size: 14px;
														font-weight: 600;
														font-family: Arial,
															Helvetica,
															sans-serif;
													"
													>The Best</a
												>
												<!--end::Title-->

												<!--begin::Desc-->
												<p
													style="
														color: #5e6278;
														font-size: 13px;
														font-weight: 500;
														padding-top: 3px;
														margin: 0;
														font-family: Arial,
															Helvetica,
															sans-serif;
													"
												>
													Gain access to all our
													services, invest, transact,
													and latest on business
													insider.
												</p>
												<!--end::Desc-->
											</div>
											<!--end::Content-->
										</div>
										<!--end::Block-->
									</div>
									<!--end::Item-->
								</div>
								<!--end::Wrapper-->
							</td>
						</tr>

						<tr>
							<td
								align="center"
								valign="center"
								style="
									font-size: 13px;
									text-align: center;
									padding: 0 10px 10px 10px;
									font-weight: 500;
									color: #a1a5b7;
									font-family: Arial, Helvetica, sans-serif;
								"
							>
								<p
									style="
										color: #181c32;
										font-size: 16px;
										font-weight: 600;
										margin-bottom: 9px;
									"
								>
									It’s all about customers!
								</p>
								<p style="margin-bottom: 2px">
									Call our customer care number: +31 6 3344 55
									56
								</p>
								<p style="margin-bottom: 4px">
									You may reach us at
									<a
										href="https://www.bancopt.com/"
										rel="noopener"
										target="_blank"
										style="font-weight: 600"
										>bancopt.com</a
									>.
								</p>
								<p>We serve Mon-Fri, 09:00-18:00</p>
							</td>
						</tr>

						<tr>
							<td
								align="center"
								valign="center"
								style="text-align: center; padding-bottom: 20px"
							>
								<a href="#" style="margin-right: 10px"
									><img
										alt="Logo"
										src="https://www.bancopt.com/assets/media/email/icon-facebook.png"
								/></a>
								<a href="#"
									><img
										alt="Logo"
										src="https://www.bancopt.com/assets/media/email/icon-twitter.png"
								/></a>
							</td>
						</tr>

						<tr>
							<td
								align="center"
								valign="center"
								style="
									font-size: 13px;
									padding: 0 15px;
									text-align: center;
									font-weight: 500;
									color: #a1a5b7;
									font-family: Arial, Helvetica, sans-serif;
								"
							>
								<p>
									&copy Copyright Bancopt.
									<a
										href="https://www.bancopt.com/"
										rel="noopener"
										target="_blank"
										style="
											font-weight: 600;
											font-family: Arial, Helvetica,
												sans-serif;
										"
										>Unsubscribe</a
									>&nbsp; from newsletter.
								</p>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</body>
</html>
`;
